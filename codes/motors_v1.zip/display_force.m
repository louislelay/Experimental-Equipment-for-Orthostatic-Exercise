function display_force(F_filter)
label_name = ["Force BR [N]", "Force BL [N]", "Force FR [N]", "Force FL [N]"];

for i = 1:4
    subplot(2, 2, i);
    plot(F_filter(:, i));
    ylabel(label_name(i), 'FontSize', 12);

end
end