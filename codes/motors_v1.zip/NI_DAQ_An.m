% https://jp.mathworks.com/help/daq/acquire-data-using-ni-devices.html
%% 初期化処理: dqが存在していなければinitialize_dqを実行する
if exist('dq', 'var') == 0
    global dq;
    dq = initialize_dq;
end
    daqreset;
    dev_list = daqlist;
    device   = dev_list.DeviceID(1); % This needs to be specified for your setup
%     device = 'Dev1'; % This needs to be specified for your setup
    s = daq('ni');
    addinput(s, device, 'port0/line0','Digital');
    t = zeros(1000,1);
    tic
    for i = 1 : 1000
        read(s,1,"OutputFormat","Matrix"); % first run of read is slower
%         read(s); % first run of read is slower
    end
    toc
%for t = 1:10000
%    force = read_force(dq);
%    str = "BR: " + num2str(force{1}) + ", BL: " + num2str(force{2}) + ", FR:" + num2str(force{3}) + ", FL:" + num2str(force{4});
%    disp(str)
%    % pause(0)
%end
% モーターを動かすときは以下のようにする
%move_motor(dq, "BR", 0.5);

%% 停止処理
%stop_motor(dq)

% PID制御のパラメータ設定​
% kp = 1;
% ki = 0.1;
% kd = 0.01;
% 
% % ターゲット値の選定
% target_value = 100;  % 適当に設定しています．　力は何もしてない状態で78とか
% 
% % write(dq,[1,0,0]);
% e_br_pre = 0;
% % ey_pre = 0;
% % ez_pre = 0;
% ie_br=0;
% % iey=0;
% % iez=0;
% 
% % モーターに出力する電圧値
% volt_BR = 0;    volt_BL = 0;
% volt_FR = 0;    volt_FL = 0;
% 
% % x軸とz軸方向からターゲット値を計算する（仮）
% for i = 1:10000
%     [force_BR, force_BL, force_FR, force_FL] = read_force;
%     % matrixdata = read(dq, "OutputFormat", "Matrix");
%     % Fx_br = (matrixdata(1)-2.50) * 500; %力の値に変換
%     % Fz_br = (matrixdata(3)-2.50) * 500; %力の値に変換
% 
%     F_br = sqrt((Fx_br.^2) + (Fz_br.^2));
% 
% 
%     % Fy = matrixdata(2);
%     % Fz = matrixdata(3);
%     e_br= target_value - F_br;
%     % ey= target_force_list(i) - Fy;
%     % ez= target_force_list(i) - Fz;
% 
% 
%     d_br = e_br - e_br_pre;
%     % dy = ey - ey_pre;
%     % dz = ez - ez_pre;
% 
%     ie_br = ie_br + (e_br + e_br_pre)/2;
%     % iey = iey + (ey + ey_pre)/2;
%     % iez = iez + (ez + ez_pre)/2;
% 
%     Volt = kp * e_br + kd * d_br + ki * ie_br;
%     e_br_pre = e_br;
%     str1 = "force:" + F_br + " Volt:" + Volt;
%     disp(str1);
%     % write(dq, [1,1,Volt]);
%     pause(0.01);
% end