% 初期化の処理
% dq{1}: BR, dq{2}: BL, dq{3}: FR, dq{4}: FL
function dq = initialize_dq()
d  = daqlist("ni");

% BR
dq{1} = daq("ni");  dq{1}.Rate = 1000; % BR
addinput(dq{1}, "Right", "ai0", "Voltage"); %Fx
addinput(dq{1}, "Right", "ai1", "Voltage"); %Fy
addinput(dq{1}, "Right", "ai2", "Voltage"); %Fz

addoutput(dq{1}, "Right", "ao0", "Voltage"); % 1 右上モータ(BR)

addoutput(dq{1}, "Right", "port1/line0", "Digital"); % 5 右上側（BR）の回転方向制御
addoutput(dq{1}, "Right", "port1/line1", "Digital"); % 6 右上側（BR）の制御

% BL
dq{2} = daq("ni");  dq{2}.Rate = 1000; % BL
addinput(dq{2}, "Left", "ai0", "Voltage");%Fx
addinput(dq{2}, "Left", "ai1", "Voltage");%Fy
addinput(dq{2}, "Left", "ai2", "Voltage");%Fz

addoutput(dq{2}, "Left",  "ao0", "Voltage"); % 3 左上モータ(BL)
% (p1.0 p1.1)=(1,0)で下がる　
% (p1.0 p1.1)=(0,1)で上がる
addoutput(dq{2}, "Left", "port1/line0", "Digital"); % 9  左上側（BL）の制御
addoutput(dq{2}, "Left", "port1/line1", "Digital"); % 10 左上側（BL）の制御

% FR
dq{3} = daq("ni");  dq{3}.Rate = 1000; % FR
addinput(dq{3}, "Right", "ai4", "Voltage"); %Fx
addinput(dq{3}, "Right", "ai5", "Voltage"); %Fy
addinput(dq{3}, "Right", "ai6", "Voltage"); %Fz

addoutput(dq{3}, "Right", "ao1", "Voltage"); % 2 右下モータ(FR)
% (p1.2 p1.3)=(1,0)で下がる　
% (p1.2 p1.3)=(0,1)で上がる
addoutput(dq{3}, "Right", "port1/line2", "Digital"); % 7 右下側（FR）の制御
addoutput(dq{3}, "Right", "port1/line3", "Digital"); % 8 右下側（FR）の制御

% FL
dq{4} = daq("ni");  dq{4}.Rate = 1000; % FL
addinput(dq{4}, "Left", "ai4", "Voltage");%Fx 10
addinput(dq{4}, "Left", "ai5", "Voltage");%Fy 11
addinput(dq{4}, "Left", "ai6", "Voltage");%Fz 12

% (p1.2 p1.3)=(1,0)で下がる　
% (p1.2 p1.3)=(0,1)で上がる
addoutput(dq{4}, "Left",  "ao1", "Voltage"); % 4 左下モータ(FL)
addoutput(dq{4}, "Left", "port1/line2", "Digital"); % 11 左下側（FL）の制御
addoutput(dq{4}, "Left", "port1/line3", "Digital"); % 12 左下側（FL）の制御

% シングルエンドに設定
for num = 1:4
    for ai = 1:3
        dq{num}.Channels(ai).TerminalConfig = "SingleEnded";
    end
end
end