% https://jp.mathworks.com/help/daq/acquire-data-using-ni-devices.html
d  = daqlist("ni");
dq = daq("ni");
dq.Rate = 1000;

% Backward-Right
addinput(dq, "Right", "ai4", "Voltage");%Fx 1
addinput(dq, "Right", "ai5", "Voltage");%Fy 2
addinput(dq, "Right", "ai6", "Voltage");%Fz 3

% Backward-Left
addinput(dq, "Left", "ai4", "Voltage");%Fx 4
addinput(dq, "Left", "ai5", "Voltage");%Fy 5
addinput(dq, "Left", "ai6", "Voltage");%Fz 6

% Forward-Right　
addinput(dq, "Right", "ai0", "Voltage");%Fx 7
addinput(dq, "Right", "ai1", "Voltage");%Fy 8
addinput(dq, "Right", "ai2", "Voltage");%Fz 9

% Forward-Left
addinput(dq, "Left", "ai0", "Voltage");%Fx 10
addinput(dq, "Left", "ai1", "Voltage");%Fy 11
addinput(dq, "Left", "ai2", "Voltage");%Fz 12

for i = 1:12
    dq.Channels(i).TerminalConfig = "SingleEnded";
end

% 出力のデバイスと番号と形式
addoutput(dq, "Right", "ao0", "Voltage"); % 1 右上モータ(BR)
addoutput(dq, "Left",  "ao0", "Voltage"); % 3 左上モータ(BL)
addoutput(dq, "Right", "ao1", "Voltage"); % 2 右下モータ(FR)
addoutput(dq, "Left",  "ao1", "Voltage"); % 4 左下モータ(FL)

% (p1.0 p1.1)=(0,0)or(1,1)の時動作しない　
% (p1.0 p1.1)=(1,0)で下がる　
% (p1.0 p1.1)=(0,1)で上がる
addoutput(dq, "Right", "port1/line0", "Digital"); % 5 右上側（BR）の回転方向制御  
addoutput(dq, "Right", "port1/line1", "Digital"); % 6 右上側（BR）の制御  

% (p1.2 p1.3)=(1,0)で下がる　
% (p1.2 p1.3)=(0,1)で上がる
addoutput(dq, "Right", "port1/line2", "Digital"); % 7 右下側（FR）の制御
addoutput(dq, "Right", "port1/line3", "Digital"); % 8 右下側（FR）の制御

% (p1.0 p1.1)=(1,0)で下がる　
% (p1.0 p1.1)=(0,1)で上がる
addoutput(dq, "Left", "port1/line0", "Digital"); % 9  左上側（BL）の制御
addoutput(dq, "Left", "port1/line1", "Digital"); % 10 左上側（BL）の制御

% (p1.2 p1.3)=(1,0)で下がる　
% (p1.2 p1.3)=(0,1)で上がる
addoutput(dq, "Left", "port1/line2", "Digital"); % 11 左下側（FL）の制御
addoutput(dq, "Left", "port1/line3", "Digital"); % 12 左下側（FL）の制御

% PID制御のパラメータ設定​
kp = 1;
ki = 0.1;
kd = 0.01;

% ターゲット値の選定
target_value = 100;  % 適当に設定しています．　力は何もしてない状態で78とか


% write(dq,[1,0,0]);
e_br_pre = 0;
% ey_pre = 0;
% ez_pre = 0;
ie_br=0;
% iey=0;
% iez=0;

% モーターに出力する電圧値
volt_BR = 0;    volt_BL = 0;
volt_FR = 0;    volt_FL = 0;

% x軸とz軸方向からターゲット値を計算する（仮）
for i = 1:10000
    [force_BR, force_BL, force_FR, force_FL] = read_force;
    % matrixdata = read(dq, "OutputFormat", "Matrix");
    % Fx_br = (matrixdata(1)-2.50) * 500; %力の値に変換
    % Fz_br = (matrixdata(3)-2.50) * 500; %力の値に変換
    
    F_br = sqrt((Fx_br.^2) + (Fz_br.^2));


    % Fy = matrixdata(2);
    % Fz = matrixdata(3);
    e_br= target_value - F_br;
    % ey= target_force_list(i) - Fy;
    % ez= target_force_list(i) - Fz;


    d_br = e_br - e_br_pre;
    % dy = ey - ey_pre;
    % dz = ez - ez_pre;

    ie_br = ie_br + (e_br + e_br_pre)/2;
    % iey = iey + (ey + ey_pre)/2;
    % iez = iez + (ez + ez_pre)/2;

    Volt = kp * e_br + kd * d_br + ki * ie_br;
    e_br_pre = e_br;
    str1 = "force:" + F_br + " Volt:" + Volt;
    disp(str1);
    % write(dq, [1,1,Volt]);
    pause(0.01);
end

% 
% for i = 1:10000
%     matrixdata = read(dq, "OutputFormat", "Matrix");
%     % disp("動いています")
%     Fx = matrixdata(1);
%     Fy = matrixdata(2);
%     Fz = matrixdata(2);
%     disp(Fx)
%     % write(dq, [0 0]);​
% end