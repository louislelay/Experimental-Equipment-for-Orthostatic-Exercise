% すべてのモーターを停止するファンクション
function stop_motor
global dq;
disp("モーターを停止します");
output = [0, 0, 0];

for motor_id = 1:4
    write(dq{motor_id}, output)
end
end