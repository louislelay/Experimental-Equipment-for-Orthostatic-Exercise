%% 初期化処理: dqが存在していなければinitialize_dqを実行する
if exist('dq', 'var') == 0
    global dq;
    dq = initialize_dq;
end

% https://jp.mathworks.com/matlabcentral/answers/513976-how-can-i-speed-up-data-acquisition
dq_input = daq("ni");
dq_input.Rate = 4000;
addinput(dq_input, "Right", "ai0", "Voltage"); 
addinput(dq_input, "Right", "ai1", "Voltage"); 
addinput(dq_input, "Right", "ai2", "Voltage"); 
addinput(dq_input, "Right", "ai3", "Voltage"); 
addinput(dq_input, "Right", "ai4", "Voltage"); 
addinput(dq_input, "Right", "ai5", "Voltage"); 

addinput(dq_input, "Left", "ai0", "Voltage"); 
addinput(dq_input, "Left", "ai1", "Voltage"); 
addinput(dq_input, "Left", "ai2", "Voltage"); 
addinput(dq_input, "Left", "ai3", "Voltage"); 
addinput(dq_input, "Left", "ai4", "Voltage"); 
addinput(dq_input, "Left", "ai5", "Voltage"); 

dq_output = daq("ni");
% dq_output.Rate = 1000;
addoutput(dq_output, "Right", "ao0", "Voltage");

tic
start(dq_input, "continuous");
for t = 1:1000
 s = read(dq_input, "OutputFormat", "Matrix");
 % write(dq_output, 0);
end
stop(dq_input)
toc

%
%for t = 1:10000
%    force = read_force(dq);
%    str = "BR: " + num2str(force{1}) + ", BL: " + num2str(force{2}) + ", FR:" + num2str(force{3}) + ", FL:" + num2str(force{4});
%    disp(str)
%    % pause(0)
%end
% モーターを動かすときは以下のようにする
%move_motor(dq, "BR", 0.5);

%% 停止処理
%stop_motor(dq)

% PID制御のパラメータ設定​
% kp = 1;
% ki = 0.1;
% kd = 0.01;
% 
% % ターゲット値の選定
% target_value = 100;  % 適当に設定しています．　力は何もしてない状態で78とか
% 
% % write(dq,[1,0,0]);
% e_br_pre = 0;
% % ey_pre = 0;
% % ez_pre = 0;
% ie_br=0;
% % iey=0;
% % iez=0;
% 
% % モーターに出力する電圧値
% volt_BR = 0;    volt_BL = 0;
% volt_FR = 0;    volt_FL = 0;
% 
% % x軸とz軸方向からターゲット値を計算する（仮）
% for i = 1:10000
%     [force_BR, force_BL, force_FR, force_FL] = read_force;
%     % matrixdata = read(dq, "OutputFormat", "Matrix");
%     % Fx_br = (matrixdata(1)-2.50) * 500; %力の値に変換
%     % Fz_br = (matrixdata(3)-2.50) * 500; %力の値に変換
% 
%     F_br = sqrt((Fx_br.^2) + (Fz_br.^2));
% 
% 
%     % Fy = matrixdata(2);
%     % Fz = matrixdata(3);
%     e_br= target_value - F_br;
%     % ey= target_force_list(i) - Fy;
%     % ez= target_force_list(i) - Fz;
% 
% 
%     d_br = e_br - e_br_pre;
%     % dy = ey - ey_pre;
%     % dz = ez - ez_pre;
% 
%     ie_br = ie_br + (e_br + e_br_pre)/2;
%     % iey = iey + (ey + ey_pre)/2;
%     % iez = iez + (ez + ez_pre)/2;
% 
%     Volt = kp * e_br + kd * d_br + ki * ie_br;
%     e_br_pre = e_br;
%     str1 = "force:" + F_br + " Volt:" + Volt;
%     disp(str1);
%     % write(dq, [1,1,Volt]);
%     pause(0.01);
% end