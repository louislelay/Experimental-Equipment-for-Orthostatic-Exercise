% 不感帯に入っているモーターを確認する
% 間にあれば 1 を返し，そうでなければ 0 を返す
function fukantai = fukantai_check(P_error, fukantai, t)

lower_check = P_error(t, :) > -fukantai;
upper_check = P_error(t, :) < fukantai;

fukantai = lower_check .* upper_check;

end