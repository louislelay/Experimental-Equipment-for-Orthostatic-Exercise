% 各モーターにおける誤差を返す
% 入力は全てのモーターの下にある力センサの値 F_filter（BR, BL, FR, FL）: duration * 4
% target_value: 4つの目標値
function [P_error, I_error, D_error] = calc_error(F_filter, target_value, t, i_duration)
    % 誤差を計算する
    temp_error = repmat(target_value, i_duration, 1) - F_filter(t-i_duration+1:t, :);

    % 比例制御のための誤差を計算する
    P_error = temp_error(end, :);

    % 積分制御のための誤差を計算する
    I_error = sum(temp_error);

    % 微分制御のための誤差を計算する
    D_error = temp_error(end, :) - temp_error(end-1, :); 
end