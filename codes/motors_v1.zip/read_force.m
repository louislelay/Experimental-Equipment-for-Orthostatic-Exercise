function force = read_force(dq)
% global dq;
% dqを引数として、力データを返す
% BR, BL, FR, FLの順番
for motor_id = 1:4
    temp = read(dq{motor_id}, "OutputFormat", "Matrix");
    force{motor_id} = (temp(1:3) - 2.5) * 500;
end
end