function Volt = plus_ff_offset(Volt, ff_offset, t)

Volt(t, Volt(t, :) > 0) = Volt(t, Volt(t, :) > 0) + ff_offset;
Volt(t, Volt(t, :) < 0) = Volt(t, Volt(t, :) < 0) - ff_offset;


end