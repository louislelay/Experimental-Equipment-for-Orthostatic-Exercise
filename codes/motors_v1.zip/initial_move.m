function Volt = initial_move(P_error, t)

out_volt = [0.4, 0.4, 0.4, 0.4];

out_volt

negative_sign = P_error(t, :) < 0;


end