% motor_id: "BR", "BL", "FR", "FL", "F", "B", "ALL"
% voltage: 4次元の配列で-10--10 を入力する
function move_motor(motor_type, voltage)
global dq;
if sum(voltage < -10) > 0 || sum(voltage > 10) > 0
    disp("入力が-10～10 Vの範囲外にあります")
    return
end

% 動かすモーターの指定
if strcmp(motor_type, "BR")
    disp("Control Back Right Motor");
    motor_id = 1;
elseif strcmp(motor_type, "BL")
    disp("Control Back Left Motor");
    motor_id = 2;
elseif strcmp(motor_type, "FR")
    disp("Control Front Right Motor");
    motor_id = 3;
elseif strcmp(motor_type, "FL")
    disp("Control Front Left Motor");
    motor_id = 4;
end


% 出力の準備
% (p1.0 p1.1)=(0,0)or(1,1)の時動作しない　
% (p1.0 p1.1)=(1,0)で下がる　
% (p1.0 p1.1)=(0,1)で上がる
if voltage >= 0
    output = [voltage, 0, 1]; % ベルトが上がる
else
    output = [-voltage, 1, 0]; % ベルトが下がる
end

% 出力
write(dq{motor_id}, output)

end