% https://jp.mathworks.com/help/daq/acquire-data-using-ni-devices.html

%% 初期化処理: dqが存在していなければinitialize_dqを実行する
if exist('dq', 'var') == 0
    global dq;
    dq = initialize_dq;
end

% PID制御のパラメータ設定​
kp = 0.025;
ki = 0.000;
kd = 0.001;
i_duration = 5;

% フィードフォワードのオフセット値
ff_offset = 0.1;

% ターゲット値の選定
% motor_id
target_value(1) = 100;  % 適当に設定しています．　力は何もしてない状態で78とか
target_value(2) = 100;
target_value(3) = 100;
target_value(4) = 100;

clear F_filter_br Volt_BR e_br temp_F_br

duration        = 200;
moving_ave_win  = 3;
fukantai        = 5;
initial_volt    = 0.39;

force       = zeros(duration, 4);
F_filter    = zeros(duration, 4);
P_error     = zeros(duration, 4);
I_error     = zeros(duration, 4);
D_error     = zeros(duration, 4);
Volt        = zeros(duration, 4);

target_first_check = 0; % まず初めに一度目標値に達するかどうか確認する

% 状態を確認する変数を設ける
% 1: 初期モード
% 2: PIDモード
state       = zeros(duration, 4);

for t = 1:duration
    disp(t);

    %% 常に力を取得しておく
    temp_force = read_force;
    % str = "BR: " + num2str(force{1}) + ", BL: " + num2str(force{2}) + ", FR:" + num2str(force{3}) + ", FL:" + num2str(force{4});
    % disp(str)

    % 力を代入する
    force(t, 1) = sqrt((temp_force{1}(1).^2) + (temp_force{1}(3).^2)); % BR
    force(t, 2) = sqrt((temp_force{2}(1).^2) + (temp_force{2}(3).^2)); % BL
    force(t, 3) = sqrt((temp_force{3}(1).^2) + (temp_force{3}(3).^2)); % FR
    force(t, 4) = sqrt((temp_force{4}(1).^2) + (temp_force{4}(3).^2)); % FL

    %% 制御を開始する
    if t > max(moving_ave_win, i_duration)
        % 移動平均を計算する
        F_filter(t, :) = mean(force(t-moving_ave_win:t, :));

        % 誤差の計算をする
        [P_error(t, :), I_error(t, :), D_error(t, :)] = calc_error(F_filter, target_value, t, i_duration);

        % まず初めに目標付近にゆっくりと近づける
        if target_first_check == 0
            disp("初期モード")
            
            % 今はBRの力だけが target_value ± fukantai になるまで制御する
            fukantai = fukantai_check(P_error, fukantai, t); 

            % 全てが不感帯に入っていれば，target_first_check を 1 にする
            if all(fukantai>0) 
                target_first_check = 1;
            else % 不感帯に入っていないモーターだけを制御する
                state(t, 1) = 0;
                Volt(t, :) = repmat(initial_volt, 1, 4);
                Volt(t, P_error(t, :) < 0) = -initial_volt; % 回転方向を決定、誤差が負のところは緩める
                Volt(t, fukantai > 0)      =  0.0; % 不感帯に入っている（1となっている）部分は 0 を入れる
            end
       else % 一度目標値に到達をしたらPID制御を開始する
            disp("PID制御モード")
            state(t, 1) = 1;

            % PID制御
            % 誤差と係数を内積で掛け合わせて、フィードフォワードのオフセットを足す
            Volt(t, :) = dot([P_error(t, 1) I_error(t, 1) D_error(t, 1)], [kp ki kd]);

            % オフセット値を入れる
            Volt(t, Volt(t, :) > 0) = Volt(t, Volt(t, :) > 0) + ff_offset;
            Volt(t, Volt(t, :) < 0) = Volt(t, Volt(t, :) < 0) - ff_offset;

            % 制限を設ける
            Volt(t, Volt(t, :) > 1.5)   = 1.5;
            Volt(t, Volt(t, :) < -1.5)  = -1.5;
            
            % 不感帯に入っているか確認
            fukantai = fukantai_check(P_error, fukantai, t);
            Volt(fukantai > 0)      =  0.0; % 不感帯に入っている（1となっている）部分は 0 を入れる
        end
        
        move_motor("BR", Volt(t, 1));
        move_motor("BL", Volt(t, 2));
        % move_motor("FR", Volt(t, 3));
        % move_motor("FL", Volt(t, 4));

        % 停止条件の設定
        if any(F_filter(t, :) > 200)
            disp("力センサの値が規定値を超えました")
            stop_motor
            return
        else
            continue
        end
    else
        F_filter(t, :) = force(t, :);
    end
end

%% 停止処理
stop_motor